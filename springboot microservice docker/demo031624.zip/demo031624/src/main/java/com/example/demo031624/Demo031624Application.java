package com.example.demo031624;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo031624Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo031624Application.class, args);
	}

}
